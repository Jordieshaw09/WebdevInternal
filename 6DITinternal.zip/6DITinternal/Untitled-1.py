import sqlite3

def run_ski_run_viewer():
    def show_all(conn):
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM info")
            ski_runs = cursor.fetchall()

            for run in ski_runs:
                print_run_info(run)

            cursor.close()
        except sqlite3.Error as e:
            print("An error occurred while fetching data from the database:", e)

    def show_remarkables(conn):
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM info WHERE Resort = 'The Remarkables'")
            remarkables_runs = cursor.fetchall()

            for run in remarkables_runs:
                print_run_info(run)

            cursor.close()
        except sqlite3.Error as e:
            print("An error occurred while fetching data from the database:", e)

    def show_coronet_peak(conn):
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM info WHERE Resort = 'Coronet Peak'")
            coronet_peak_runs = cursor.fetchall()

            for run in coronet_peak_runs:
                print_run_info(run)

            cursor.close()
        except sqlite3.Error as e:
            print("An error occurred while fetching data from the database:", e)

    def print_run_info(run):
        try:
            resort = run[1]
            run_name = run[2]
            
            print("Resort is:", resort)
            print("Run Name:", run_name)
            print()
        except IndexError:
            print("Error: Incomplete run information")

    valid_choices = ['1', '2', '3']
    choice = None

    while choice not in valid_choices:
        print("Please choose from the following options:")
        print("Type 1 to view all ski runs up The Remarkables and Coronet Peak")
        print("Type 2 to view ski runs up The Remarkables")
        print("Type 3 to view ski runs up Coronet Peak")
        choice = input(": ")

        if choice not in valid_choices:
            print("Invalid choice. Please try again.\n")

    with sqlite3.connect('6DITinternal.db') as conn:
        if choice == "1":
            show_all(conn)
        elif choice == "2":
            show_remarkables(conn)
        elif choice == "3":
            show_coronet_peak(conn)

    more_info_choice = ""

    while more_info_choice.lower() not in ['yes', 'no']:
        more_info_choice = input("Would you like to know more about a specific run? (yes/no): ")

        if more_info_choice.lower() not in ['yes', 'no']:
            print("thats not an option please type yes or no because that is the only acceptable answer1.\n")

    if more_info_choice.lower() == "yes":
        run_name = input("Enter the name of the run: ")
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT Level, Access_method, Night_skiing FROM info WHERE Run_Name = ?", (run_name,))
            run_info = cursor.fetchone()

            if run_info:
                level = run_info[0]
                access_method = run_info[1]
                night_skiing = run_info[2]

                print("Run Name:", run_name)
                print("Level:", level)
                print("Access Method:", access_method)
                if night_skiing == 'yes':
                    print("This run does have night skiing.")
                else:
                    print("This run doesn't have night skiing.")
            else:
                print("Run not found, if you typed it with all lowercase try it with the first letter of each word as capitals. E.G Alta Blue")

            cursor.close()
        except sqlite3.Error as e:
            print("An error occurred while fetching run information from the database:", e)
    else:
        print("Thanks for running my code! :)")

run_ski_run_viewer()
